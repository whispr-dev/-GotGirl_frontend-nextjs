"use strict";
exports.id = 7260;
exports.ids = [7260];
exports.modules = {

/***/ 7491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer_01)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./src/components/logo/index.jsx
var logo = __webpack_require__(3451);
;// CONCATENATED MODULE: ./src/components/widgets/logo-widget/index.jsx



const LogoWidget = ({ data  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "footer-left",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(logo/* default */.Z, {
                logo: data.logo
            }),
            (data === null || data === void 0 ? void 0 : data.text) && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "rn-footer-describe",
                children: data.text
            })
        ]
    }));
};
LogoWidget.propTypes = {
    data: external_prop_types_default().shape({
        logo: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            src: (external_prop_types_default()).string.isRequired,
            alt: (external_prop_types_default()).string
        })),
        text: (external_prop_types_default()).string
    })
};
/* harmony default export */ const logo_widget = (LogoWidget);

;// CONCATENATED MODULE: ./src/components/widgets/newsletter-widget/index.jsx


const NewsletterWidget = ({ data  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "widget-bottom mt--40 pt--40",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "title",
                children: data.title
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        className: "form-control bg-color--2",
                        placeholder: "Your username",
                        "aria-label": "Recipient's username"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "input-group-append",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "btn btn-primary-alta btn-outline-secondary",
                            type: "button",
                            children: "Subscribe"
                        })
                    })
                ]
            }),
            (data === null || data === void 0 ? void 0 : data.note) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "newsletter-dsc",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: data.note
                })
            })
        ]
    }));
};
NewsletterWidget.propTypes = {
    data: external_prop_types_default().shape({
        title: (external_prop_types_default()).string,
        note: (external_prop_types_default()).string
    })
};
/* harmony default export */ const newsletter_widget = (NewsletterWidget);

// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(1967);
;// CONCATENATED MODULE: ./src/components/widgets/quicklink-widget/index.jsx



const QuicklinkWidget = ({ data  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "footer-widget widget-quicklink",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "widget-title",
                children: data.title
            }),
            (data === null || data === void 0 ? void 0 : data.menu) && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "footer-list-one",
                children: data.menu.map((nav)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "single-list",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                            path: nav.path,
                            children: nav.text
                        })
                    }, nav.id)
                )
            })
        ]
    }));
};
QuicklinkWidget.propTypes = {
    data: external_prop_types_default().shape({
        title: (external_prop_types_default()).string,
        menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            id: external_prop_types_default().oneOfType([
                (external_prop_types_default()).number,
                (external_prop_types_default()).string
            ]).isRequired,
            text: (external_prop_types_default()).string.isRequired,
            path: (external_prop_types_default()).string.isRequired
        }))
    })
};
/* harmony default export */ const quicklink_widget = (QuicklinkWidget);

;// CONCATENATED MODULE: ./src/components/widgets/information-widget/index.jsx



const InformationWidget = ({ data  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "footer-widget widget-information",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "widget-title",
                children: data.title
            }),
            (data === null || data === void 0 ? void 0 : data.menu) && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "footer-list-one",
                children: data.menu.map((nav)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "single-list",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                            path: nav.path,
                            children: nav.text
                        })
                    }, nav.id)
                )
            })
        ]
    }));
};
InformationWidget.propTypes = {
    data: external_prop_types_default().shape({
        title: (external_prop_types_default()).string,
        menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            id: external_prop_types_default().oneOfType([
                (external_prop_types_default()).number,
                (external_prop_types_default()).string
            ]).isRequired,
            text: (external_prop_types_default()).string.isRequired,
            path: (external_prop_types_default()).string.isRequired
        }))
    })
};
/* harmony default export */ const information_widget = (InformationWidget);

;// CONCATENATED MODULE: ./src/components/widgets/sold-out-widget/index.jsx




const SoldOutWidget = ({ data  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "footer-widget",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "widget-title",
                children: data.title
            }),
            (data === null || data === void 0 ? void 0 : data.products) && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "footer-recent-post",
                children: data.products.map((product)=>{
                    var ref, ref1;
                    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "recent-post",
                        children: [
                            ((ref = product.image) === null || ref === void 0 ? void 0 : ref.src) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "thumbnail",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                    path: product.path,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        src: product.image.src,
                                        alt: ((ref1 = product.image) === null || ref1 === void 0 ? void 0 : ref1.alt) || "Product Images",
                                        layout: "fixed",
                                        width: 60,
                                        height: 60
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "content",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        className: "title",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                            path: product.path,
                                            children: product.title
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: product.highestBid
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "price",
                                        children: product.price
                                    })
                                ]
                            })
                        ]
                    }, product.id));
                })
            })
        ]
    }));
};
SoldOutWidget.propTypes = {
    data: external_prop_types_default().shape({
        title: (external_prop_types_default()).string,
        products: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            id: external_prop_types_default().oneOfType([
                (external_prop_types_default()).number,
                (external_prop_types_default()).string
            ]).isRequired,
            title: (external_prop_types_default()).string.isRequired,
            path: (external_prop_types_default()).string.isRequired,
            highestBid: (external_prop_types_default()).string.isRequired,
            price: (external_prop_types_default()).string.isRequired,
            image: external_prop_types_default().shape({
                src: (external_prop_types_default()).string.isRequired,
                alt: (external_prop_types_default()).string
            })
        }))
    })
};
/* harmony default export */ const sold_out_widget = (SoldOutWidget);

;// CONCATENATED MODULE: ./src/components/widgets/footer-link-widget/index.jsx



const FooterLinkWidget = ({ data  })=>{
    var ref;
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "privacy",
        children: data === null || data === void 0 ? void 0 : (ref = data.menu) === null || ref === void 0 ? void 0 : ref.map((nav)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                    path: nav.path,
                    children: nav.text
                })
            }, nav.id)
        )
    }));
};
FooterLinkWidget.propTypes = {
    data: external_prop_types_default().shape({
        menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            id: external_prop_types_default().oneOfType([
                (external_prop_types_default()).number,
                (external_prop_types_default()).string
            ]).isRequired,
            text: (external_prop_types_default()).string.isRequired,
            path: (external_prop_types_default()).string.isRequired
        }))
    })
};
/* harmony default export */ const footer_link_widget = (FooterLinkWidget);

;// CONCATENATED MODULE: ./src/components/widgets/social-widget/index.jsx


const SocialWidget = ({ socials  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "social-copyright",
        children: socials === null || socials === void 0 ? void 0 : socials.map((social)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: social.link,
                    target: "_blank",
                    rel: "noreferrer",
                    "aria-label": social.title,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: social.icon
                    })
                })
            }, social.id)
        )
    }));
};
SocialWidget.propTypes = {
    socials: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: external_prop_types_default().oneOfType([
            (external_prop_types_default()).number,
            (external_prop_types_default()).string
        ]).isRequired,
        icon: (external_prop_types_default()).string.isRequired,
        link: (external_prop_types_default()).string.isRequired,
        title: (external_prop_types_default()).string.isRequired
    }))
};
/* harmony default export */ const social_widget = (SocialWidget);

// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(312);
;// CONCATENATED MODULE: ./src/data/general/footer-01.json
const footer_01_namespaceObject = JSON.parse('{"e7":{"logo":[{"src":"/images/logo/logo-white.png","alt":"logo"}],"text":"Created with the collaboration of over 60 of the world\'s best Nuron Artists."},"eN":{"title":"Get The Latest Nuron Updates","note":"Email is safe. We don\'t spam."},"zT":{"title":"Nuron","menu":[{"id":1,"text":"Protocol Explore","path":"/explore-01"},{"id":2,"text":"System Token","path":"/about"},{"id":3,"text":"Otimize Time","path":"/about"},{"id":4,"text":"Visual Checking","path":"/about"},{"id":5,"text":"Fadeup System","path":"/blog"},{"id":6,"text":"Activity Log","path":"/activity"},{"id":7,"text":"System Auto Since","path":"/blog"}]},"zn":{"title":"Information","menu":[{"id":1,"text":"Market Explore","path":"/explore-01"},{"id":2,"text":"Ready Token","path":"/about"},{"id":3,"text":"Otimize Time","path":"/about"},{"id":4,"text":"Main Option","path":"/about"},{"id":5,"text":"Blog Grid","path":"/blog"},{"id":6,"text":"About Us","path":"/about"},{"id":7,"text":"Fix Bug","path":"/blog"}]},"N1":{"title":"Recent Sold Out","products":[{"id":1,"title":"#21 The Wonder","path":"/product","highestBid":"Highest bid 1/20","price":"0.244wETH","image":{"src":"/images/portfolio/portfolio-01.jpg"}},{"id":2,"title":"Diamond Dog","path":"/product","highestBid":"Highest bid 1/20","price":"0.022wETH","image":{"src":"/images/portfolio/portfolio-02.jpg"}},{"id":3,"title":"Morgan11","path":"/product","highestBid":"Highest bid 1/20","price":"0.892wETH","image":{"src":"/images/portfolio/portfolio-03.jpg"}}]},"zk":{"menu":[{"id":1,"text":"Terms","path":"/terms-condition"},{"id":2,"text":"Privacy Policy","path":"/privacy-policy"}]},"M6":"©2022 Nuron, Inc. All rights reserved"}');
;// CONCATENATED MODULE: ./src/data/general/contact.json
const contact_namespaceObject = JSON.parse('{"M":[{"id":1,"icon":"feather-facebook","link":"https://facebook.com","title":"Facebook"},{"id":2,"icon":"feather-twitter","link":"https://twitter.com","title":"Twitter"},{"id":3,"icon":"feather-instagram","link":"https://instagram.com","title":"Instagram"},{"id":4,"icon":"feather-linkedin","link":"https://linkedin.com","title":"linkedin"},{"id":5,"icon":"feather-mail","link":"https://mail.com","title":"mail"}]}');
;// CONCATENATED MODULE: ./src/layouts/footer/footer-01/index.jsx












// Demo data


const Footer = ({ space , className , data  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: external_clsx_default()("rn-footer-one bg-color--1", space === 1 && "rn-section-gap mt--100 mt_md--80 mt_sm--80", space === 2 && "rn-section-gap", space === 3 && "mt--100 mt_md--80 mt_sm--80", className),
                children: [
                    (data === null || data === void 0 ? void 0 : data.items) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer-top",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "nu-brand-area",
                                    children: data.items.map(({ id , image  })=>{
                                        return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: (image === null || image === void 0 ? void 0 : image.src) && /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                src: image.src,
                                                alt: (image === null || image === void 0 ? void 0 : image.alt) || "nuron-brand_nft",
                                                layout: "fill",
                                                objectFit: "contain"
                                            })
                                        }, id));
                                    })
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row gx-5",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-3 col-md-6 col-sm-6 col-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "widget-content-wrapper",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(logo_widget, {
                                                data: footer_01_namespaceObject.e7
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(newsletter_widget, {
                                                data: footer_01_namespaceObject.eN
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-3 col-md-6 col-sm-6 col-12 mt_mobile--40",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(quicklink_widget, {
                                        data: footer_01_namespaceObject.zT
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-3 col-md-6 col-sm-6 col-12 mt_md--40 mt_sm--40",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(information_widget, {
                                        data: footer_01_namespaceObject.zn
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-3 col-md-6 col-sm-6 col-12 mt_md--40 mt_sm--40",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(sold_out_widget, {
                                        data: footer_01_namespaceObject.N1
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "copy-right-one ptb--20 bg-color--1",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-6 col-md-12 col-sm-12",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "copyright-left",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: footer_01_namespaceObject.M6
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(footer_link_widget, {
                                            data: footer_01_namespaceObject.zk
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-6 col-md-12 col-sm-12",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "copyright-right",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(social_widget, {
                                        socials: contact_namespaceObject.M
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
Footer.propTypes = {
    space: external_prop_types_default().oneOf([
        1,
        2,
        3
    ]),
    className: (external_prop_types_default()).string,
    data: external_prop_types_default().shape({
        items: external_prop_types_default().arrayOf(types/* ItemType */.qG)
    })
};
Footer.defaultProps = {
    space: 1
};
/* harmony default export */ const footer_01 = (Footer);


/***/ }),

/***/ 1586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header_01)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: external "react-moralis"
var external_react_moralis_ = __webpack_require__(6921);
// EXTERNAL MODULE: ./src/components/logo/index.jsx
var components_logo = __webpack_require__(3451);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(1967);
;// CONCATENATED MODULE: ./src/components/menu/main-menu/submenu.jsx



const SubMenu = ({ menu  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "submenu",
        children: menu.map((nav)=>{
            return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                    path: nav.path,
                    className: nav.isLive ? "live-expo" : "",
                    children: [
                        nav.text,
                        (nav === null || nav === void 0 ? void 0 : nav.icon) && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: `feather ${nav.icon}`
                        })
                    ]
                })
            }, nav.id));
        })
    }));
};
SubMenu.propTypes = {
    menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))
};
/* harmony default export */ const submenu = (SubMenu);

;// CONCATENATED MODULE: ./src/components/menu/main-menu/megamenu.jsx



const MegaMenu = ({ menu  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "rn-megamenu",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "wrapper",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row row--0",
                children: menu.map((nav)=>{
                    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 single-mega-item",
                        children: (nav === null || nav === void 0 ? void 0 : nav.submenu) && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "mega-menu-item",
                            children: nav.submenu.map((subnav)=>{
                                return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                                        path: subnav.path,
                                        children: [
                                            subnav.text,
                                            (subnav === null || subnav === void 0 ? void 0 : subnav.icon) && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: `feather ${subnav.icon}`
                                            })
                                        ]
                                    })
                                }, subnav.id));
                            })
                        })
                    }, nav.id));
                })
            })
        })
    }));
};
MegaMenu.propTypes = {
    menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))
};
/* harmony default export */ const megamenu = (MegaMenu);

;// CONCATENATED MODULE: ./src/components/menu/main-menu/index.jsx






const MainMenu = ({ menu  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "mainmenu",
        children: menu.map((nav)=>{
            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                className: external_clsx_default()(!!nav.submenu && "has-droupdown has-menu-child-item", !!nav.megamenu && "with-megamenu"),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                        className: "its_new",
                        path: nav.path,
                        children: nav.text
                    }),
                    (nav === null || nav === void 0 ? void 0 : nav.submenu) && /*#__PURE__*/ jsx_runtime_.jsx(submenu, {
                        menu: nav.submenu
                    }),
                    (nav === null || nav === void 0 ? void 0 : nav.megamenu) && /*#__PURE__*/ jsx_runtime_.jsx(megamenu, {
                        menu: nav.megamenu
                    })
                ]
            }, nav.id));
        })
    }));
};
MainMenu.propTypes = {
    menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))
};
/* harmony default export */ const main_menu = (MainMenu);

// EXTERNAL MODULE: ./src/components/ui/offcanvas/index.js + 3 modules
var offcanvas = __webpack_require__(3014);
// EXTERNAL MODULE: ./src/utils/methods.js
var methods = __webpack_require__(5369);
;// CONCATENATED MODULE: ./src/components/menu/mobile-menu/submenu.jsx



const submenu_SubMenu = ({ menu  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "submenu mobile-menu-children",
        children: menu.map((nav)=>{
            return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                    path: nav.path,
                    children: [
                        nav.text,
                        (nav === null || nav === void 0 ? void 0 : nav.icon) && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: `feather ${nav.icon}`
                        })
                    ]
                })
            }, nav.id));
        })
    }));
};
submenu_SubMenu.propTypes = {
    menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))
};
/* harmony default export */ const mobile_menu_submenu = (submenu_SubMenu);

;// CONCATENATED MODULE: ./src/components/menu/mobile-menu/megamenu.jsx



const megamenu_MegaMenu = ({ menu  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "rn-megamenu mobile-menu-children",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "wrapper",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row row--0",
                children: menu.map((nav)=>{
                    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 single-mega-item",
                        children: (nav === null || nav === void 0 ? void 0 : nav.submenu) && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "mega-menu-item",
                            children: nav.submenu.map((subnav)=>{
                                return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                                        path: subnav.path,
                                        children: [
                                            subnav.text,
                                            (subnav === null || subnav === void 0 ? void 0 : subnav.icon) && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: `feather ${subnav.icon}`
                                            })
                                        ]
                                    })
                                }, subnav.id));
                            })
                        })
                    }, nav.id));
                })
            })
        })
    }));
};
megamenu_MegaMenu.propTypes = {
    menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))
};
/* harmony default export */ const mobile_menu_megamenu = (megamenu_MegaMenu);

;// CONCATENATED MODULE: ./src/components/menu/mobile-menu/index.jsx









const MobileMenu = ({ isOpen , onClick , menu , logo  })=>{
    const onClickHandler = (e)=>{
        e.preventDefault();
        const { target  } = e;
        const { parentElement: { parentElement: { childNodes  } ,  } , nextElementSibling ,  } = target;
        (0,methods.slideToggle)(nextElementSibling);
        childNodes.forEach((child)=>{
            if (child.id === target.parentElement.id) return;
            if (child.classList.contains("has-children")) {
                (0,methods.slideUp)(child.lastElementChild);
            }
        });
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(offcanvas/* Offcanvas */.TB, {
        isOpen: isOpen,
        onClick: onClick,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(offcanvas/* OffcanvasHeader */.Us, {
                onClick: onClick,
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_logo/* default */.Z, {
                    logo: logo
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(offcanvas/* OffcanvasBody */.UT, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "mainmenu",
                        children: menu === null || menu === void 0 ? void 0 : menu.map((nav)=>{
                            const hasChildren = !!nav.submenu || !!nav.megamenu;
                            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: external_clsx_default()(!!nav.submenu && "has-droupdown", !!nav.megamenu && "with-megamenu", hasChildren && "has-children"),
                                id: nav.id,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                        className: "nav-link its_new",
                                        path: hasChildren ? "#!" : nav.path,
                                        onClick: hasChildren ? onClickHandler : (e)=>e
                                        ,
                                        children: nav.text
                                    }),
                                    (nav === null || nav === void 0 ? void 0 : nav.submenu) && /*#__PURE__*/ jsx_runtime_.jsx(mobile_menu_submenu, {
                                        menu: nav.submenu
                                    }),
                                    (nav === null || nav === void 0 ? void 0 : nav.megamenu) && /*#__PURE__*/ jsx_runtime_.jsx(mobile_menu_megamenu, {
                                        menu: nav.megamenu
                                    })
                                ]
                            }, nav.id));
                        })
                    })
                })
            })
        ]
    }));
};
MobileMenu.propTypes = {
    isOpen: (external_prop_types_default()).bool.isRequired,
    onClick: (external_prop_types_default()).func.isRequired,
    menu: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    })),
    logo: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        src: (external_prop_types_default()).string.isRequired,
        alt: (external_prop_types_default()).string
    }))
};
/* harmony default export */ const mobile_menu = (MobileMenu);

;// CONCATENATED MODULE: ./src/components/search-form/layout-01/index.jsx

const SearchForm = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "search-form-wrapper",
        action: "#",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "search",
                placeholder: "Search Here",
                "aria-label": "Search"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "search-icon",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "button",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "feather-search"
                    })
                })
            })
        ]
    })
;
/* harmony default export */ const layout_01 = (SearchForm);

// EXTERNAL MODULE: ./src/components/search-form/layout-02/index.jsx
var layout_02 = __webpack_require__(4830);
// EXTERNAL MODULE: ./src/components/user-dropdown/index.jsx
var user_dropdown = __webpack_require__(9666);
// EXTERNAL MODULE: ./src/components/color-switcher/index.jsx
var color_switcher = __webpack_require__(8323);
// EXTERNAL MODULE: ./src/components/ui/burger-button/index.jsx
var burger_button = __webpack_require__(5321);
// EXTERNAL MODULE: ./src/components/ui/button/index.jsx
var ui_button = __webpack_require__(1257);
// EXTERNAL MODULE: ./src/hooks/index.js + 4 modules
var hooks = __webpack_require__(1029);
;// CONCATENATED MODULE: ./src/data/general/header-01.json
const header_01_namespaceObject = JSON.parse('{"j":[{"src":"/images/logo/logo-white.png"},{"src":"/images/logo/logo-dark.png"}],"Q":"/activity"}');
;// CONCATENATED MODULE: ./src/data/general/menu-01.json
const menu_01_namespaceObject = JSON.parse('[{"id":1,"text":"Home","path":"/","submenu":[{"id":11,"text":"Home Page One","path":"/","icon":"feather-home"},{"id":12,"text":"Home Page Two","path":"/index-02","icon":"feather-home"},{"id":13,"text":"Home Page Three","path":"/index-03","icon":"feather-home"},{"id":14,"text":"Home Page Four","path":"/index-04","icon":"feather-home"},{"id":15,"text":"Home Page Five","path":"/index-05","icon":"feather-home"},{"id":16,"text":"Home Page Six","path":"/index-06","icon":"feather-home"},{"id":17,"text":"Home Page Seven","path":"/index-07","icon":"feather-home"},{"id":18,"text":"Home Page Eight","path":"/index-08","icon":"feather-home"},{"id":19,"text":"Home Page Nine","path":"/index-09","icon":"feather-home"},{"id":120,"text":"Home Page Ten","path":"/index-10","icon":"feather-home"},{"id":121,"text":"Home Page Eleven","path":"/index-11","icon":"feather-home"},{"id":122,"text":"Home Page Twelve","path":"/index-12","icon":"feather-home"},{"id":123,"text":"Home Page Thirteen","path":"/index-13","icon":"feather-home"},{"id":124,"text":"Home Page Fourteen","path":"/index-14","icon":"feather-home"},{"id":125,"text":"Home Page Fifteen","path":"/index-15","icon":"feather-home"},{"id":126,"text":"Home Page Sixteen","path":"/index-16","icon":"feather-home"}]},{"id":2,"text":"About","path":"/about"},{"id":3,"text":"Explore","path":"#!","submenu":[{"id":11,"text":"Explore Filter","path":"/explore-01"},{"id":31,"text":"Explore Isotop","path":"/explore-02"},{"id":32,"text":"Explore Carousel","path":"/explore-03"},{"id":33,"text":"Explore Simple","path":"/explore-04"},{"id":34,"text":"Explore Place Bid","path":"/explore-05"},{"id":35,"text":"Place Bid With Filter","path":"/explore-06"},{"id":36,"text":"Place Bid With Isotop","path":"/explore-07"},{"id":37,"text":"Place Bid With Carousel","path":"/explore-08"},{"id":38,"text":"Explore Style List","path":"/explore-09"},{"id":39,"text":"Explore List Col-Two","path":"/explore-10"},{"id":390,"text":"Live Explore","path":"/explore-11","isLive":true},{"id":391,"text":"Live Explore Carousel","path":"/explore-12","isLive":true},{"id":392,"text":"Live With Place Bid","path":"/explore-13","isLive":true}]},{"id":4,"text":"Pages","path":"#!","megamenu":[{"id":41,"submenu":[{"id":410,"text":"Create NFT","path":"/create","icon":"feather-file-plus"},{"id":411,"text":"Upload Type","path":"/upload-variants","icon":"feather-layers"},{"id":412,"text":"Activity","path":"/activity","icon":"feather-activity"},{"id":413,"text":"Creators","path":"/creator","icon":"feather-users"},{"id":414,"text":"Our Collection","path":"/collection","icon":"feather-package"},{"id":415,"text":"Upcoming Projects","path":"/upcoming-projects","icon":"feather-loader"}]},{"id":42,"submenu":[{"id":420,"text":"Log In","path":"/login","icon":"feather-log-in"},{"id":421,"text":"Registration","path":"/sign-up","icon":"feather-user-plus"},{"id":422,"text":"Forget Password","path":"/forget","icon":"feather-lock"},{"id":423,"text":"Author/Profile(User)","path":"/author","icon":"feather-user"},{"id":424,"text":"Connect to Wallet","path":"/connect","icon":"feather-pocket"},{"id":425,"text":"Privacy Policy","path":"/privacy-policy","icon":"feather-file-text"}]},{"id":43,"submenu":[{"id":430,"text":"Product","path":"/product","icon":"feather-folder"},{"id":431,"text":"Product Details","path":"/product/delta25","icon":"feather-layout"},{"id":432,"text":"NFT Ranking","path":"/ranking","icon":"feather-trending-up"},{"id":433,"text":"Edit Profile","path":"/edit-profile","icon":"feather-edit"},{"id":434,"text":"Blog Details","path":"/blog/blog-21","icon":"feather-book-open"},{"id":435,"text":"404","path":"/404","icon":"feather-alert-triangle"}]},{"id":44,"submenu":[{"id":441,"text":"About Us","path":"/about","icon":"feather-award"},{"id":442,"text":"Contact","path":"/contact","icon":"feather-headphones"},{"id":443,"text":"Support/FAQ","path":"/support","icon":"feather-help-circle"},{"id":444,"text":"Terms & Condition","path":"/terms-condition","icon":"feather-list"},{"id":445,"text":"Coming Soon","path":"/coming-soon","icon":"feather-clock"},{"id":446,"text":"Maintenance","path":"/maintenance","icon":"feather-cpu"}]}]},{"id":5,"text":"Blog","path":"/blog","submenu":[{"id":51,"text":"Blog Single Column","path":"/blog-single-column","icon":"feather-fast-forward"},{"id":52,"text":"Blog Two Column","path":"/blog-col-two","icon":"feather-fast-forward"},{"id":53,"text":"Blog Three Column","path":"/blog-col-three","icon":"feather-fast-forward"},{"id":54,"text":"Blog Four Column","path":"/blog","icon":"feather-fast-forward"},{"id":55,"text":"Blog Details","path":"/blog/blog-9","icon":"feather-fast-forward"}]},{"id":6,"text":"Contact","path":"/contact"}]');
;// CONCATENATED MODULE: ./src/layouts/header/header-01/index.jsx

















const Header = ({ className  })=>{
    const sticky = (0,hooks/* useSticky */.Ax)();
    const { offcanvas , offcanvasHandler  } = (0,hooks/* useOffcanvas */.vI)();
    const { search , searchHandler  } = (0,hooks/* useFlyoutSearch */.Dm)();
    const { authenticate , isAuthenticated  } = (0,external_react_moralis_.useMoralis)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: external_clsx_default()("rn-header haeder-default black-logo-version header--fixed header--sticky", sticky && "sticky", className),
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "header-inner",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "header-left",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(components_logo/* default */.Z, {
                                        logo: header_01_namespaceObject.j
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mainmenu-wrapper",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                            id: "sideNav",
                                            className: "mainmenu-nav d-none d-xl-block",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(main_menu, {
                                                menu: menu_01_namespaceObject
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "header-right",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "setting-option d-none d-lg-block",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(layout_01, {
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "setting-option rn-icon-list d-block d-lg-none",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "icon-box search-mobile-icon",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "button",
                                                    "aria-label": "Click here to open search form",
                                                    onClick: searchHandler,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "feather-search"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(layout_02/* default */.Z, {
                                                isOpen: search
                                            })
                                        ]
                                    }),
                                    !isAuthenticated && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "setting-option header-btn",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "icon-box",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* default */.Z, {
                                                color: "primary-alta",
                                                className: "connectBtn",
                                                size: "small",
                                                onClick: ()=>authenticate()
                                                ,
                                                children: "Wallet connect"
                                            })
                                        })
                                    }),
                                    isAuthenticated && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "setting-option rn-icon-list user-account",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(user_dropdown/* default */.Z, {
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "setting-option rn-icon-list notification-badge",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "icon-box",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                                                path: header_01_namespaceObject.Q,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "feather-bell"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "badge",
                                                        children: "6"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "setting-option mobile-menu-bar d-block d-xl-none",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "hamberger",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(burger_button/* default */.Z, {
                                                onClick: offcanvasHandler
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        id: "my_switcher",
                                        className: "setting-option my_switcher",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(color_switcher/* default */.Z, {
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(mobile_menu, {
                isOpen: offcanvas,
                onClick: offcanvasHandler,
                menu: menu_01_namespaceObject,
                logo: header_01_namespaceObject.j
            })
        ]
    }));
};
Header.propTypes = {
    className: (external_prop_types_default()).string
};
/* harmony default export */ const header_01 = (Header);


/***/ })

};
;