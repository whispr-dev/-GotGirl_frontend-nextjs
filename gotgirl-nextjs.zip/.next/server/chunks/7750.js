"use strict";
exports.id = 7750;
exports.ids = [7750];
exports.modules = {

/***/ 7750:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ blog_sidebar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(1967);
// EXTERNAL MODULE: ./src/utils/methods.js
var methods = __webpack_require__(5369);
;// CONCATENATED MODULE: ./src/components/widgets/category-widget/index.jsx




const CategoryWidget = ({ categories , rootPage  })=>{
    const cats = [];
    categories === null || categories === void 0 ? void 0 : categories.forEach((cat)=>{
        const obj = {
            ...cat,
            count: 1
        };
        const objIndex = (0,methods.containsObject)(obj, cats);
        if (objIndex !== -1) {
            const prevCount = cats[objIndex].count;
            cats[objIndex] = {
                title: cat.title,
                slug: cat.slug,
                count: prevCount + 1
            };
        } else {
            cats.push(obj);
        }
    });
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rbt-single-widget widget_categories",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "title",
                children: "Categories"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "inner",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "category-list",
                    children: cats === null || cats === void 0 ? void 0 : cats.map((cat)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                                path: `${rootPage}/category/${cat.slug}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "left-content",
                                        children: cat.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "count-text",
                                        children: cat.count
                                    })
                                ]
                            })
                        }, cat.slug)
                    )
                })
            })
        ]
    }));
};
CategoryWidget.propTypes = {
    categories: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    })),
    rootPage: (external_prop_types_default()).string
};
CategoryWidget.defaultProps = {
    rootPage: "/blog"
};
/* harmony default export */ const category_widget = (CategoryWidget);

;// CONCATENATED MODULE: ./src/components/widgets/recent-posts-widget/index.jsx



const RecentPostsWidget = ({ recentPosts , rootPage  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rbt-single-widget widget_recent_entries mt--40",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "title",
                children: "Recent Posts"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "inner",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    children: recentPosts === null || recentPosts === void 0 ? void 0 : recentPosts.map((post)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                    className: "d-block",
                                    path: `${rootPage}/${post.slug}`,
                                    children: post.title
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "cate",
                                    children: post.category.title
                                })
                            ]
                        }, post.slug)
                    )
                })
            })
        ]
    }));
};
RecentPostsWidget.propTypes = {
    recentPosts: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        title: (external_prop_types_default()).string,
        slug: (external_prop_types_default()).string,
        category: external_prop_types_default().shape({
            title: (external_prop_types_default()).string
        })
    })),
    rootPage: (external_prop_types_default()).string
};
RecentPostsWidget.defaultProps = {
    rootPage: "/blog"
};
/* harmony default export */ const recent_posts_widget = (RecentPostsWidget);

;// CONCATENATED MODULE: ./src/components/widgets/tag-widget/index.jsx




const TagWidget = ({ tags , rootPage  })=>{
    const tagss = [
        ...new Set((0,methods.flatDeep)(tags).map((tag)=>tag.title
        ))
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rbt-single-widget widget_tag_cloud mt--40",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "title",
                children: "Tags"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "inner mt--20",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "tagcloud",
                    children: tagss === null || tagss === void 0 ? void 0 : tagss.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                            path: `${rootPage}/tag/${(0,methods.slugify)(tag)}`,
                            children: tag
                        }, tag)
                    )
                })
            })
        ]
    }));
};
TagWidget.propTypes = {
    tags: external_prop_types_default().arrayOf(external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))),
    rootPage: (external_prop_types_default()).string
};
TagWidget.defaultProps = {
    rootPage: "/blog"
};
/* harmony default export */ const tag_widget = (TagWidget);

;// CONCATENATED MODULE: ./src/containers/blog-sidebar/index.jsx






const BlogSidebar = ({ className , categories , recentPosts , tags , rootPage ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
        className: external_clsx_default()("rwt-sidebar", className),
        children: [
            (categories === null || categories === void 0 ? void 0 : categories.length) > 0 && /*#__PURE__*/ jsx_runtime_.jsx(category_widget, {
                categories: categories,
                rootPage: rootPage
            }),
            (recentPosts === null || recentPosts === void 0 ? void 0 : recentPosts.length) > 0 && /*#__PURE__*/ jsx_runtime_.jsx(recent_posts_widget, {
                recentPosts: recentPosts,
                rootPage: rootPage
            }),
            (tags === null || tags === void 0 ? void 0 : tags.length) > 0 && /*#__PURE__*/ jsx_runtime_.jsx(tag_widget, {
                tags: tags,
                rootPage: rootPage
            })
        ]
    }));
};
BlogSidebar.propTypes = {
    className: (external_prop_types_default()).string,
    categories: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    })),
    recentPosts: external_prop_types_default().arrayOf(external_prop_types_default().shape({
    })),
    tags: external_prop_types_default().arrayOf(external_prop_types_default().arrayOf(external_prop_types_default().shape({
    }))),
    rootPage: (external_prop_types_default()).string
};
/* harmony default export */ const blog_sidebar = (BlogSidebar);


/***/ })

};
;