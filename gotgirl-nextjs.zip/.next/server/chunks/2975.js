"use strict";
exports.id = 2975;
exports.ids = [2975];
exports.modules = {

/***/ 3028:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_anchor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);




const Collection = ({ title , total_item , image , thumbnails , profile_image , path ,  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_anchor__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        path: path,
        className: "rn-collection-inner-one",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "collection-wrapper",
            children: [
                (image === null || image === void 0 ? void 0 : image.src) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "collection-big-thumbnail",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        src: image.src,
                        alt: (image === null || image === void 0 ? void 0 : image.alt) || "Nft_Profile",
                        width: 507,
                        height: 339
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "collenction-small-thumbnail",
                    children: thumbnails === null || thumbnails === void 0 ? void 0 : thumbnails.map((thumb, i)=>{
                        return(// eslint-disable-next-line react/no-array-index-key
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                src: thumb === null || thumb === void 0 ? void 0 : thumb.src,
                                alt: (thumb === null || thumb === void 0 ? void 0 : thumb.alt) || "Nft_Profile",
                                width: 164,
                                height: 110
                            })
                        }, i));
                    })
                }),
                (profile_image === null || profile_image === void 0 ? void 0 : profile_image.src) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "collection-profile",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        src: profile_image.src,
                        alt: (profile_image === null || profile_image === void 0 ? void 0 : profile_image.alt) || "Nft_Profile",
                        width: 80,
                        height: 80
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "collection-deg",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "title",
                            children: title
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "items",
                            children: [
                                total_item,
                                " items"
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
Collection.propTypes = {
    title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
    total_item: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().number.isRequired),
    path: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
    image: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        src: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOfType([
            prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape(),
            (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
        ]).isRequired,
        alt: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
    }).isRequired,
    thumbnails: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        src: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOfType([
            prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape(),
            (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
        ]).isRequired,
        alt: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
    }).isRequired).isRequired,
    profile_image: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        src: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOfType([
            prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape(),
            (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
        ]).isRequired,
        alt: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
    }).isRequired
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Collection);


/***/ }),

/***/ 5908:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"title":"Cubic Trad","slug":"/collection","total_item":27,"image":{"src":"/images/collection/collection-lg-01.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-01.jpg"},{"src":"/images/collection/collection-sm-02.jpg"},{"src":"/images/collection/collection-sm-03.jpg"}],"profile_image":{"src":"/images/client/client-15.png"}},{"id":2,"title":"Diamond Dog","slug":"/collection","total_item":20,"image":{"src":"/images/collection/collection-lg-02.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-04.jpg"},{"src":"/images/collection/collection-sm-05.jpg"},{"src":"/images/collection/collection-sm-06.jpg"}],"profile_image":{"src":"/images/client/client-12.png"}},{"id":3,"title":"Morgan11","slug":"/collection","total_item":15,"image":{"src":"/images/collection/collection-lg-03.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-07.jpg"},{"src":"/images/collection/collection-sm-08.jpg"},{"src":"/images/collection/collection-sm-09.jpg"}],"profile_image":{"src":"/images/client/client-13.png"}},{"id":4,"title":"Orthogon#720","slug":"/collection","total_item":27,"image":{"src":"/images/collection/collection-lg-04.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-10.jpg"},{"src":"/images/collection/collection-sm-11.jpg"},{"src":"/images/collection/collection-sm-12.jpg"}],"profile_image":{"src":"/images/client/client-14.png"}},{"id":5,"title":"Trad Mard","slug":"/collection","total_item":35,"image":{"src":"/images/collection/collection-lg-02.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-01.jpg"},{"src":"/images/collection/collection-sm-02.jpg"},{"src":"/images/collection/collection-sm-03.jpg"}],"profile_image":{"src":"/images/client/client-15.png"}},{"id":6,"title":"Dog Eligator","slug":"/collection","total_item":82,"image":{"src":"/images/collection/collection-lg-04.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-04.jpg"},{"src":"/images/collection/collection-sm-05.jpg"},{"src":"/images/collection/collection-sm-06.jpg"}],"profile_image":{"src":"/images/client/client-12.png"}},{"id":7,"title":"Dog Eligator","slug":"/collection","total_item":10,"image":{"src":"/images/collection/collection-lg-05.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-07.jpg"},{"src":"/images/collection/collection-sm-08.jpg"},{"src":"/images/collection/collection-sm-09.jpg"}],"profile_image":{"src":"/images/client/client-13.png"}},{"id":8,"title":"Thememove","slug":"/collection","total_item":82,"image":{"src":"/images/collection/collection-lg-01.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-10.jpg"},{"src":"/images/collection/collection-sm-11.jpg"},{"src":"/images/collection/collection-sm-12.jpg"}],"profile_image":{"src":"/images/client/client-14.png"}},{"id":9,"title":"Quarter Trad","slug":"/collection","total_item":15,"image":{"src":"/images/collection/collection-lg-02.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-02.jpg"},{"src":"/images/collection/collection-sm-04.jpg"},{"src":"/images/collection/collection-sm-07.jpg"}],"profile_image":{"src":"/images/client/client-11.png"}},{"id":10,"title":"Cat Eligator","slug":"/collection","total_item":56,"image":{"src":"/images/collection/collection-lg-04.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-01.jpg"},{"src":"/images/collection/collection-sm-02.jpg"},{"src":"/images/collection/collection-sm-05.jpg"}],"profile_image":{"src":"/images/client/client-12.png"}},{"id":11,"title":"Monas Nine","slug":"/collection","total_item":56,"image":{"src":"/images/collection/collection-lg-03.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-03.jpg"},{"src":"/images/collection/collection-sm-05.jpg"},{"src":"/images/collection/collection-sm-06.jpg"}],"profile_image":{"src":"/images/client/client-13.png"}},{"id":12,"title":"Golden dog","slug":"/collection","total_item":40,"image":{"src":"/images/collection/collection-lg-02.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-04.jpg"},{"src":"/images/collection/collection-sm-08.jpg"},{"src":"/images/collection/collection-sm-10.jpg"}],"profile_image":{"src":"/images/client/client-14.png"}},{"id":13,"title":"Golden Cat","slug":"/collection","total_item":35,"image":{"src":"/images/collection/collection-lg-04.jpg"},"thumbnails":[{"src":"/images/collection/collection-sm-02.jpg"},{"src":"/images/collection/collection-sm-09.jpg"},{"src":"/images/collection/collection-sm-06.jpg"}],"profile_image":{"src":"/images/client/client-12.png"}}]');

/***/ })

};
;