"use strict";
(() => {
var exports = {};
exports.id = 2521;
exports.ids = [2521];
exports.modules = {

/***/ 6365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);



const SectionTitle = ({ title , className , disableAnimation , ...restProps })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("title", className),
        "data-sal-delay": "150",
        "data-sal": !disableAnimation && "slide-up",
        "data-sal-duration": "800",
        ...restProps,
        dangerouslySetInnerHTML: {
            __html: title
        }
    })
;
SectionTitle.propTypes = {
    title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
    subtitle: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    disableAnimation: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionTitle);


/***/ }),

/***/ 1483:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);



const Sticky = ({ children , className , top  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("widge-wrapper", className),
        style: {
            top
        },
        children: children
    })
;
Sticky.propTypes = {
    children: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().node.isRequired),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    top: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
};
Sticky.defaultProps = {
    top: "100px"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sticky);


/***/ }),

/***/ 645:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ about_layout_02)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./src/components/section-title/layout-02/index.jsx
var layout_02 = __webpack_require__(6365);
// EXTERNAL MODULE: ./src/components/ui/button/index.jsx
var ui_button = __webpack_require__(1257);
;// CONCATENATED MODULE: ./src/components/about-card/index.jsx




const AboutCard = ({ className , title , desc , path  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("rn-about-card", className),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "inner",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "title",
                    "data-sal": "slide-up",
                    "data-sal-duration": "800",
                    "data-sal-delay": "150",
                    dangerouslySetInnerHTML: {
                        __html: title
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "about-disc",
                    "data-sal": "slide-up",
                    "data-sal-duration": "800",
                    "data-sal-delay": "150",
                    children: desc
                }),
                path && /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* default */.Z, {
                    path: path,
                    color: "primary-alta",
                    className: "sal-animate mt--20",
                    "data-sal": "slide-up",
                    "data-sal-duration": "800",
                    "data-sal-delay": "150",
                    children: "See Our Blog"
                })
            ]
        })
    })
;
AboutCard.propTypes = {
    className: (external_prop_types_default()).string,
    title: (external_prop_types_default()).string.isRequired,
    desc: (external_prop_types_default()).string.isRequired,
    path: (external_prop_types_default()).string
};
/* harmony default export */ const about_card = (AboutCard);

// EXTERNAL MODULE: ./src/components/ui/sticky/index.jsx
var sticky = __webpack_require__(1483);
// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(312);
;// CONCATENATED MODULE: ./src/containers/about/layout-02/index.jsx








const AboutArea = ({ space , className , data  })=>{
    var ref, ref1, ref2, ref3;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_clsx_default()("rn-about-banner-area", space === 1 && "rn-section-gapTop", className),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container mb--30",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12",
                        children: (data === null || data === void 0 ? void 0 : data.section_title) && /*#__PURE__*/ jsx_runtime_.jsx(layout_02/* default */.Z, {
                            className: "about-title-m",
                            ...data.section_title
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container-fluid about-fluidimg ",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "img-wrapper",
                        children: (data === null || data === void 0 ? void 0 : (ref = data.image) === null || ref === void 0 ? void 0 : ref.src) && /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: data.image.src,
                            alt: ((ref1 = data.image) === null || ref1 === void 0 ? void 0 : ref1.alt) || "Slider BG",
                            layout: "fill",
                            objectFit: "cover",
                            quality: 100,
                            priority: true
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row g-5",
                    children: [
                        (data === null || data === void 0 ? void 0 : (ref2 = data.items) === null || ref2 === void 0 ? void 0 : ref2[0]) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h--100",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(sticky/* default */.Z, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(about_card, {
                                        className: "mt_dec--50 widge-wrapper rbt-sticky-top-adjust",
                                        title: data.items[0].title,
                                        desc: data.items[0].description,
                                        path: data.items[0].path
                                    })
                                })
                            })
                        }),
                        (data === null || data === void 0 ? void 0 : (ref3 = data.items) === null || ref3 === void 0 ? void 0 : ref3[1]) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(about_card, {
                                className: "transparent-bg",
                                title: data.items[1].title,
                                desc: data.items[1].description,
                                path: data.items[1].path
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
AboutArea.propTypes = {
    space: external_prop_types_default().oneOf([
        1,
        2
    ]),
    className: (external_prop_types_default()).string,
    data: external_prop_types_default().shape({
        section_title: types/* SectionTitleType */.K0,
        image: types/* ImageType */.__,
        items: external_prop_types_default().arrayOf(types/* ItemType */.qG)
    })
};
AboutArea.defaultProps = {
    space: 1
};
/* harmony default export */ const about_layout_02 = (AboutArea);


/***/ }),

/***/ 8062:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6365);
/* harmony import */ var _ui_anchor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1967);
/* harmony import */ var _components_blog_blog_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6970);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(312);







const BlogArea = ({ space , className , data  })=>{
    var ref;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("rn-blog-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row mb--50 align-items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-6 col-md-6 col-sm-6 col-12",
                            children: (data === null || data === void 0 ? void 0 : data.section_title) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                className: "mb--0",
                                ...data.section_title
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-6 col-md-6 col-sm-6 col-12 mt_mobile--15",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "view-more-btn text-start text-sm-end",
                                "data-sal-delay": "150",
                                "data-sal": "slide-up",
                                "data-sal-duration": "800",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_anchor__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    className: "btn-transparent",
                                    path: "/blog",
                                    children: [
                                        "VIEW ALL",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "feather-arrow-right"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-5",
                    children: data === null || data === void 0 ? void 0 : (ref = data.posts) === null || ref === void 0 ? void 0 : ref.map((post)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xl-3 col-lg-4 col-md-6 col-12",
                            "data-sal": "slide-up",
                            "data-sal-duration": "800",
                            "data-sal-delay": "150",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_blog_blog_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                title: post.title,
                                slug: post.slug,
                                category: post.category,
                                timeToRead: post.timeToRead,
                                image: post.image
                            })
                        }, post.slug)
                    )
                })
            ]
        })
    }));
};
BlogArea.propTypes = {
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1,
        2
    ]),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    data: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        section_title: _utils_types__WEBPACK_IMPORTED_MODULE_6__/* .SectionTitleType */ .K0,
        posts: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        }))
    })
};
BlogArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogArea);


/***/ }),

/***/ 9080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1257);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(312);






const CTAArea = ({ space , className , data  })=>{
    var ref, ref1, ref2;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("rn-callto-action", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container-fluid about-fluidimg-cta",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-lg-12 position-relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "about-image",
                            children: (data === null || data === void 0 ? void 0 : (ref = data.image) === null || ref === void 0 ? void 0 : ref.src) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                src: data.image.src,
                                alt: data.image.alt || "cta BG",
                                layout: "fill",
                                objectFit: "cover",
                                quality: 100,
                                priority: true
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "call-to-action-wrapper",
                            children: [
                                data === null || data === void 0 ? void 0 : (ref1 = data.headings) === null || ref1 === void 0 ? void 0 : ref1.map((heading)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        "data-sal": "slide-up",
                                        "data-sal-duration": "800",
                                        "data-sal-delay": "150",
                                        dangerouslySetInnerHTML: {
                                            __html: heading.content
                                        }
                                    }, heading.id)
                                ),
                                data === null || data === void 0 ? void 0 : (ref2 = data.texts) === null || ref2 === void 0 ? void 0 : ref2.map((text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        "data-sal": "slide-up",
                                        "data-sal-duration": "800",
                                        "data-sal-delay": "150",
                                        dangerouslySetInnerHTML: {
                                            __html: text.content
                                        }
                                    }, text.id)
                                ),
                                (data === null || data === void 0 ? void 0 : data.buttons) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "callto-action-btn-wrapper",
                                    "data-sal": "slide-up",
                                    "data-sal-duration": "800",
                                    "data-sal-delay": "150",
                                    children: data.buttons.map(({ id , content , ...rest })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            ...rest,
                                            children: content
                                        }, id)
                                    )
                                })
                            ]
                        })
                    ]
                })
            })
        })
    }));
};
CTAArea.propTypes = {
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1,
        2
    ]),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    data: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        texts: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_5__/* .TextType */ .yG),
        headings: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_5__/* .HeadingType */ .nQ),
        buttons: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_5__/* .ButtonType */ .L$),
        image: _utils_types__WEBPACK_IMPORTED_MODULE_5__/* .ImageType */ .__
    })
};
CTAArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CTAArea);


/***/ }),

/***/ 5402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ funfact)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-countup"
var external_react_countup_ = __webpack_require__(609);
var external_react_countup_default = /*#__PURE__*/__webpack_require__.n(external_react_countup_);
// EXTERNAL MODULE: external "react-intersection-observer"
var external_react_intersection_observer_ = __webpack_require__(9785);
;// CONCATENATED MODULE: ./src/components/funfact/layout-01/index.jsx






const FunFact = ({ className , counter , title , suffix  })=>{
    const { 0: focus , 1: setFocus  } = (0,external_react_.useState)(false);
    const visibleChangeHandler = (isVisible)=>{
        if (isVisible) {
            if (!focus) {
                setFocus(true);
            }
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_clsx_default()("single-counter-up text-center", className),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "number counter-odomitter-active",
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_countup_default()), {
                    start: focus ? 0 : null,
                    end: counter,
                    duration: 5,
                    children: ({ countUpRef  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    ref: countUpRef
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_intersection_observer_.InView, {
                                    as: "span",
                                    onChange: (inView)=>visibleChangeHandler(inView)
                                    ,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "visually-hidden",
                                                children: "+"
                                            }),
                                            suffix && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: suffix
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                })
            }),
            title && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "botton-title",
                children: title
            })
        ]
    }));
};
FunFact.propTypes = {
    className: (external_prop_types_default()).string,
    counter: (external_prop_types_default()).number.isRequired,
    title: (external_prop_types_default()).string,
    suffix: (external_prop_types_default()).string
};
/* harmony default export */ const layout_01 = (FunFact);

// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(312);
;// CONCATENATED MODULE: ./src/containers/funfact/index.jsx





const FunfactArea = ({ space , className , data  })=>{
    var ref;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("rn-statistick-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row mb--30",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 text-center",
                        children: (data === null || data === void 0 ? void 0 : data.section_title) && /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: data.section_title.title
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-8",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row g-5",
                            children: data === null || data === void 0 ? void 0 : (ref = data.funfacts) === null || ref === void 0 ? void 0 : ref.map((funfact)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-md-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(layout_01, {
                                        counter: funfact.counter,
                                        title: funfact.title,
                                        suffix: funfact.suffix
                                    })
                                }, funfact.id)
                            )
                        })
                    })
                })
            ]
        })
    }));
};
FunfactArea.propTypes = {
    space: external_prop_types_default().oneOf([
        1,
        2
    ]),
    className: (external_prop_types_default()).string,
    data: external_prop_types_default().shape({
        section_title: types/* SectionTitleType */.K0,
        funfacts: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            counter: (external_prop_types_default()).number.isRequired,
            title: (external_prop_types_default()).string,
            suffix: (external_prop_types_default()).string
        }))
    })
};
FunfactArea.defaultProps = {
    space: 1
};
/* harmony default export */ const funfact = (FunfactArea);


/***/ }),

/***/ 341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6365);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(312);





const QuoteArea = ({ space , className , data  })=>{
    var ref;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("rn-about-Quote-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row g-5 d-flex align-items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "rn-about-title-wrapper",
                            children: (data === null || data === void 0 ? void 0 : data.section_title) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                ...data.section_title
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "rn-about-wrapper",
                            "data-sal": "slide-up",
                            "data-sal-duration": "800",
                            "data-sal-delay": "150",
                            children: data === null || data === void 0 ? void 0 : (ref = data.texts) === null || ref === void 0 ? void 0 : ref.map((text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: text.content
                                }, text.id)
                            )
                        })
                    })
                ]
            })
        })
    }));
};
QuoteArea.propTypes = {
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1,
        2
    ]),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    data: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        section_title: _utils_types__WEBPACK_IMPORTED_MODULE_4__/* .SectionTitleType */ .K0,
        texts: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_4__/* .TextType */ .yG)
    })
};
QuoteArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuoteArea);


/***/ }),

/***/ 4160:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7569);
/* harmony import */ var _layout_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8331);
/* harmony import */ var _layout_header_header_01__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1586);
/* harmony import */ var _layout_footer_footer_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7491);
/* harmony import */ var _containers_about_layout_02__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(645);
/* harmony import */ var _containers_quote_area__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(341);
/* harmony import */ var _containers_funfact__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5402);
/* harmony import */ var _containers_cta__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9080);
/* harmony import */ var _containers_blog_layout_01__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8062);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5369);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _lib_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7636);
/* harmony import */ var _data_innerpages_about_json__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1913);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_api__WEBPACK_IMPORTED_MODULE_12__]);
_lib_api__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];













// Demo data

const About = ({ posts  })=>{
    const content = (0,_utils_methods__WEBPACK_IMPORTED_MODULE_11__.normalizedData)((_data_innerpages_about_json__WEBPACK_IMPORTED_MODULE_13__ === null || _data_innerpages_about_json__WEBPACK_IMPORTED_MODULE_13__ === void 0 ? void 0 : _data_innerpages_about_json__WEBPACK_IMPORTED_MODULE_13__.content) || []);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_wrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                pageTitle: "About"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_header_header_01__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                id: "main-content",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_containers_about_layout_02__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        data: content["about-section"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_containers_quote_area__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        data: content["quote-section"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_containers_funfact__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        data: content["funfact-section"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_containers_cta__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        data: content["cta-section"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_containers_blog_layout_01__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        data: {
                            ...content["blog-section"],
                            posts
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_footer_footer_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            })
        ]
    }));
};
async function getStaticProps() {
    const posts = (0,_lib_api__WEBPACK_IMPORTED_MODULE_12__/* .getAllPosts */ .Bd)([
        "title",
        "date",
        "slug",
        "image",
        "category",
        "timeToRead", 
    ]);
    return {
        props: {
            posts: posts.slice(0, 4),
            className: "template-color-1"
        }
    };
}
About.propTypes = {
    posts: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
    }))
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);

});

/***/ }),

/***/ 8103:
/***/ ((module) => {

module.exports = require("clsx");

/***/ }),

/***/ 8076:
/***/ ((module) => {

module.exports = require("gray-matter");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 609:
/***/ ((module) => {

module.exports = require("react-countup");

/***/ }),

/***/ 9785:
/***/ ((module) => {

module.exports = require("react-intersection-observer");

/***/ }),

/***/ 6921:
/***/ ((module) => {

module.exports = require("react-moralis");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 8974:
/***/ ((module) => {

module.exports = import("marked");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 1913:
/***/ ((module) => {

module.exports = JSON.parse('{"title":"about","content":[{"section":"about-section","section_title":{"title":"Direct Teams. <br> For Your Dadicated Dreams"},"image":{"src":"/images/bg/bg-image-22.jpg"},"items":[{"id":1,"title":"Why We Do This","description":"NFTs are virtual tokens that represent ownership of something inherently distinct and scarce, whether it be a physical or digital item, such as artwork, a soundtrack, a collectible, an in-game item or real estate. Unlike regular cryptocurrencies like bitcoin or fiat money like the U.S.","path":"/blog"},{"id":2,"title":"Helping You <br/> Grow In Every Stage.","description":"NFTs are virtual tokens that represent ownership of something inherently distinct and scarce, whether it be a physical or digital item, such as artwork, a soundtrack, a collectible, an in-game item or real estate. Unlike regular cryptocurrencies like bitcoin or fiat money like the U.S."}]},{"section":"quote-section","section_title":{"title":"Create, Sell well & Collect your Wonderful NFTs at Nuron Very Fast"},"texts":[{"id":1,"content":"The NFTs is a one-trick pony that climbed the ladders of success in recent years. The growth NFTs is tremendous, and according to Pymnts.com, the total sales volume of NFTs has nearly crossed $2.5 billion in the last six months of 2021. Surprisingly, the total sales volume of NFTs was $13.7 million in 2020. On comparing both the values,"}]},{"section":"funfact-section","section_title":{"title":"Nuron Statistics"},"funfacts":[{"id":1,"title":"Nuron All NFT\'s","counter":100},{"id":2,"title":"All Creators","counter":500,"suffix":"+"},{"id":3,"title":"Nuron Earning","counter":700},{"id":4,"title":"Level One Seller","counter":900,"suffix":"+"}]},{"section":"cta-section","headings":[{"id":1,"content":"Discover Discover Discover rare digital art <br/> and collect NFTs"}],"texts":[{"id":1,"content":"The NFTs is a one-trick pony that climbed the recent years. The growth of NFTs is tremendous, and according to Pymnts.com, the total sales volume"}],"buttons":[{"id":1,"path":"/create","content":"Create"},{"id":2,"path":"/contact","content":"Contact Us","color":"primary-alta"}],"image":{"src":"/images/bg/bg-image-6.jpg"}},{"section":"blog-section","section_title":{"title":"Our Recent Blog"}}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7730,3061,365,1257,1513,7260,3918], () => (__webpack_exec__(4160)));
module.exports = __webpack_exports__;

})();