"use strict";
exports.id = 19;
exports.ids = [19];
exports.modules = {

/***/ 19:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6365);
/* harmony import */ var _components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9634);
/* harmony import */ var _ui_nice_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5082);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(312);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5369);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_8__);









const TopSellerArea = ({ className , space , id , data  })=>{
    const { 0: current , 1: setCurrent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("1 day");
    const { 0: sellers , 1: setSellers  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const changeHandler = (item)=>{
        setCurrent(item.value);
    };
    const filterHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        const allSellers = data.sellers;
        const filterdSellers = allSellers.filter((seller)=>(0,_utils_methods__WEBPACK_IMPORTED_MODULE_8__.slugify)(seller.top_since) === (0,_utils_methods__WEBPACK_IMPORTED_MODULE_8__.slugify)(current)
        );
        setSellers(filterdSellers);
    }, [
        current,
        data.sellers
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        filterHandler();
    }, [
        filterHandler
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("rn-top-top-seller-area nice-selector-transparent", space === 1 && "rn-section-gapTop", space === 2 && "rn-section-gapBottom", space === 3 && "pt--50", className),
        id: id,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mb--30",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-12 justify-sm-center d-flex",
                        children: [
                            (data === null || data === void 0 ? void 0 : data.section_title) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                ...data.section_title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                options: [
                                    {
                                        value: "1 day",
                                        text: "1 day"
                                    },
                                    {
                                        value: "7 Day's",
                                        text: "7 Day's"
                                    },
                                    {
                                        value: "15 Day's",
                                        text: "15 Day's"
                                    },
                                    {
                                        value: "30 Day's",
                                        text: "30 Day's"
                                    }, 
                                ],
                                defaultCurrent: 0,
                                name: "sellerSort",
                                onChange: changeHandler
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row justify-sm-center g-5 top-seller-list-wrapper",
                    children: sellers.map((seller)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-5 col-lg-3 col-md-4 col-sm-6 top-seller-list",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                name: seller.name,
                                total_sale: seller.total_sale,
                                slug: seller.slug,
                                image: seller.image
                            })
                        }, seller.id)
                    )
                })
            ]
        })
    }));
};
TopSellerArea.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    id: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1,
        2,
        3
    ]),
    data: prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({
        section_title: _utils_types__WEBPACK_IMPORTED_MODULE_7__/* .SectionTitleType */ .K0,
        sellers: prop_types__WEBPACK_IMPORTED_MODULE_2___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_7__/* .SellerType */ .Df)
    })
};
TopSellerArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopSellerArea);


/***/ })

};
;