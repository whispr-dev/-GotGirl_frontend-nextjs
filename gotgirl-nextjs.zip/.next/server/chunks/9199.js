"use strict";
exports.id = 9199;
exports.ids = [9199];
exports.modules = {

/***/ 9199:
/***/ ((module) => {

module.exports = JSON.parse('{"title":"home-04","content":[{"section":"hero-section","badge":"Nuron Marketplace","title":"Search your rare NFT\'s by world  <br/>  class artists","description":"Where Bitcoin was hailed as the digital answer to currency, NFTs <br/> are now being touted as the digital answer to collectables.","buttons":[{"id":1,"path":"/login","content":"Get Started"},{"id":2,"path":"/create","color":"primary-alta","content":"Create"}],"banners":[{"id":1,"title":"Sukanli","client":"Bordcast","path":"/collection","image":{"src":"/images/banner/banner-04.jpg"}},{"id":2,"title":"HasLivbe","client":"Md. Master","path":"/collection","image":{"src":"/images/banner/banner-01.jpg"}},{"id":3,"title":"Ladicon Mos","client":"John Lee","path":"/collection","image":{"src":"/images/banner/banner-02.jpg"}},{"id":4,"title":"Masters","client":"Keenlee","path":"/collection","image":{"src":"/images/banner/banner-03.jpg"}}]},{"section":"live-explore-section","section_title":{"title":"Live Bidding"}},{"section":"explore-product-section","section_title":{"title":"Explore Product"}},{"section":"top-sller-section","section_title":{"title":"Top Seller in"}},{"section":"service-section","section_title":{"title":"Create and sell your NFTs"},"items":[{"id":1,"title":"Set up your wallet","path":"/connect","subtitle":"Step-01","description":"Powerful features and inclusions, which makes Nuron standout, easily customizable and scalable.","images":[{"src":"/images/icons/shape-7.png"}]},{"id":2,"title":"Create your collection","path":"/collection","subtitle":"Step-02","description":"A great collection of beautiful website templates for your need. Choose the best suitable template.","images":[{"src":"/images/icons/shape-1.png"}]},{"id":3,"title":"Add your NFT\'s","path":"/connect","subtitle":"Step-03","description":"We\'ve made the template fully responsive, so it looks great on all devices: desktop, tablets and.","images":[{"src":"/images/icons/shape-5.png"}]},{"id":4,"title":"Sell Your NFT\'s","path":"/creator","subtitle":"Step-04","description":"I throw myself down among the tall grass by the stream as I lie close to the earth NFT\'s.","images":[{"src":"/images/icons/shape-6.png"}]}]},{"section":"collection-section","section_title":{"title":"Top Collection"}}]}');

/***/ })

};
;